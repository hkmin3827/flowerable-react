import { useAuthStore } from "@/features/auth/store";
import axios, { AxiosError, InternalAxiosRequestConfig } from "axios";

// Axios instance 생성
export const axiosInstance = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "/api",
  timeout: 10000,
  headers: {
    "Content-Type": "application/json",
  },
});

const reissueAxios = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "/api",
});

// Request interceptor
axiosInstance.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const accessToken = useAuthStore.getState().accessToken;
    if (accessToken) {
      config.headers.Authorization = `Bearer ${accessToken}`;
    }
    return config;
  },
  (error: AxiosError) => {
    console.error("❌ Axios Request Error:", error);
    return Promise.reject(error);
  },
);

axiosInstance.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    const status = error.response?.status;
    const message = error.response?.data?.message;

    if (originalRequest.url?.includes("/auth/reissue")) {
      useAuthStore.getState().clearAuth();
      return Promise.reject(error);
    }

    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      try {
        const { refreshToken, accountStatus } = useAuthStore.getState();

        if (!refreshToken) {
          throw new Error("No refresh token");
        }

        const res = await reissueAxios.post("/auth/reissue", null, {
          headers: {
            "X-Refresh-Token": refreshToken,
            Authorization: "",
          },
        });

        const {
          accessToken,
          refreshToken: newRefreshToken,
          accountStatus: newAccountStatus,
        } = res.data;
        const current = useAuthStore.getState();
        useAuthStore.getState().updateTokens({
          accessToken,
          refreshToken: newRefreshToken ?? current.refreshToken,
          accountStatus: newAccountStatus ?? accountStatus,
        });

        originalRequest.headers.Authorization = `Bearer ${accessToken}`;

        return axiosInstance(originalRequest);
      } catch (reissueError) {
        useAuthStore.getState().clearAuth();
        return Promise.reject(reissueError);
      }
    }

    if (status === 403) {
      alert(message ?? "접근 권한이 없습니다.");
      return Promise.reject(error);
    }
    alert(message ?? "알 수 없는 오류가 발생했습니다.");
    return Promise.reject(error);
  },
);
